﻿using Microsoft.EntityFrameworkCore;
using taskMVC.Models;

namespace taskMVC.Data
{
    public class Context: DbContext
    {
        public Context(DbContextOptions options): base (options) { }

        public DbSet<Models.Task> tasks { get; set; }
        public DbSet<Project> projects { get; set; }
        public DbSet<TeamMember> teamMembers  { get; set; }

    }
}
