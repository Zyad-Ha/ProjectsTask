﻿using System.ComponentModel.DataAnnotations;

namespace taskMVC.Models
{
    public class Project
    {
        [Key]
        public int P_id { get; set; }

        [MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(500)]
        public string Description { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public ICollection<Task> Tasks { get; set; } = new HashSet<Task>();
    }
}
