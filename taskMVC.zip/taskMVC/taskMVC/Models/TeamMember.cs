﻿using System.ComponentModel.DataAnnotations;

namespace taskMVC.Models
{
    public class TeamMember
    {
        [Key]
        public int TM_id { get; set; }

        [MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(100)]
        public string Email { get; set; }

        [MaxLength(50)]
        public string Role { get; set; }

        public ICollection<Task> Tasks { get; set; } = new HashSet<Task>();
    }
}
