﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace taskMVC.Models
{
    public class Task
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100)]
        public string Title { get; set; }

        [MaxLength(500)]
        public string Description { get; set; }

        public Status Status { get; set; }

        public Priority Priority { get; set; }

        public DateTime Deadline { get; set; }

        public int ProjectID { get; set; }

        [ForeignKey("ProjectID")]
        public Project Project { get; set; }
        public int TeamMemberID { get; set; }

        [ForeignKey("TeamMemberID")]
        public TeamMember TeamMember { get; set; }
    }

    public enum Status
    {
        Pending,
        InProgress,
        Completed
    }

    public enum Priority
    {
        Low,
        Medium,
        High
    }
}
