﻿using Microsoft.AspNetCore.Mvc;
using taskMVC.Data;
using taskMVC.Models;
using taskMVC.ViewModels;

namespace taskMVC.Repos
{
    public interface IProjectRepo
    {
        void Create(Project project);

        void Update(Project project);
        void Delete(int id);
        Project Details(int id);
        IEnumerable<Project> GetAll();

    }
}
