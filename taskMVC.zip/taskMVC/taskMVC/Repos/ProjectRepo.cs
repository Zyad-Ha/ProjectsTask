﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using taskMVC.Data;
using taskMVC.Models;
using taskMVC.ViewModels;
using Task = taskMVC.Models.Task;

namespace taskMVC.Repos
{
    public class ProjectRepo : IProjectRepo
    {
        private readonly Context _context;
        public ProjectRepo(Context context) 
        {
            _context = context;
        }


        public void Create(Project project)
        {
            _context.projects.Add(project);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var delProject = _context.projects.Find(id);
            if (delProject != null)
            {
                _context.projects.Remove(delProject);
                _context.SaveChanges();
            }
            
        }

        public Project Details(int id)
        {
                var project = _context.projects
            .Include(x => x.Tasks)
            .ThenInclude(t => t.TeamMember)
            .FirstOrDefault(u => u.P_id == id);

            return project;
            
        }

        public IEnumerable<Project> GetAll()
        {
            return _context.projects.ToList();
        }

        

        public void Update(Project project)
        {
            _context.projects.Update(project);
            _context.SaveChanges();
        }
    }
}
