﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace taskMVC.Migrations
{
    /// <inheritdoc />
    public partial class Zyadd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tasks_projects_ProjectId",
                table: "tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_tasks_teamMembers_TeamMemberId",
                table: "tasks");

            migrationBuilder.RenameColumn(
                name: "TeamMemberId",
                table: "tasks",
                newName: "TeamMemberID");

            migrationBuilder.RenameColumn(
                name: "ProjectId",
                table: "tasks",
                newName: "ProjectID");

            migrationBuilder.RenameIndex(
                name: "IX_tasks_TeamMemberId",
                table: "tasks",
                newName: "IX_tasks_TeamMemberID");

            migrationBuilder.RenameIndex(
                name: "IX_tasks_ProjectId",
                table: "tasks",
                newName: "IX_tasks_ProjectID");

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_projects_ProjectID",
                table: "tasks",
                column: "ProjectID",
                principalTable: "projects",
                principalColumn: "P_id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_teamMembers_TeamMemberID",
                table: "tasks",
                column: "TeamMemberID",
                principalTable: "teamMembers",
                principalColumn: "TM_id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tasks_projects_ProjectID",
                table: "tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_tasks_teamMembers_TeamMemberID",
                table: "tasks");

            migrationBuilder.RenameColumn(
                name: "TeamMemberID",
                table: "tasks",
                newName: "TeamMemberId");

            migrationBuilder.RenameColumn(
                name: "ProjectID",
                table: "tasks",
                newName: "ProjectId");

            migrationBuilder.RenameIndex(
                name: "IX_tasks_TeamMemberID",
                table: "tasks",
                newName: "IX_tasks_TeamMemberId");

            migrationBuilder.RenameIndex(
                name: "IX_tasks_ProjectID",
                table: "tasks",
                newName: "IX_tasks_ProjectId");

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_projects_ProjectId",
                table: "tasks",
                column: "ProjectId",
                principalTable: "projects",
                principalColumn: "P_id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_teamMembers_TeamMemberId",
                table: "tasks",
                column: "TeamMemberId",
                principalTable: "teamMembers",
                principalColumn: "TM_id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
