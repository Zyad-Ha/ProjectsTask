﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace taskMVC.Migrations
{
    /// <inheritdoc />
    public partial class m1m : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProjectTask");

            migrationBuilder.DropTable(
                name: "TaskTeamMember");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "tasks",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "priority",
                table: "tasks",
                newName: "Priority");

            migrationBuilder.RenameColumn(
                name: "TeamMemberID",
                table: "tasks",
                newName: "TeamMemberId");

            migrationBuilder.RenameColumn(
                name: "ProjectID",
                table: "tasks",
                newName: "ProjectId");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "tasks",
                newName: "Title");

            migrationBuilder.RenameColumn(
                name: "T_id",
                table: "tasks",
                newName: "Id");

            migrationBuilder.AlterColumn<string>(
                name: "Role",
                table: "teamMembers",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "teamMembers",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50);

            migrationBuilder.CreateIndex(
                name: "IX_tasks_ProjectId",
                table: "tasks",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_tasks_TeamMemberId",
                table: "tasks",
                column: "TeamMemberId");

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_projects_ProjectId",
                table: "tasks",
                column: "ProjectId",
                principalTable: "projects",
                principalColumn: "P_id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_teamMembers_TeamMemberId",
                table: "tasks",
                column: "TeamMemberId",
                principalTable: "teamMembers",
                principalColumn: "TM_id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tasks_projects_ProjectId",
                table: "tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_tasks_teamMembers_TeamMemberId",
                table: "tasks");

            migrationBuilder.DropIndex(
                name: "IX_tasks_ProjectId",
                table: "tasks");

            migrationBuilder.DropIndex(
                name: "IX_tasks_TeamMemberId",
                table: "tasks");

            migrationBuilder.RenameColumn(
                name: "TeamMemberId",
                table: "tasks",
                newName: "TeamMemberID");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "tasks",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "ProjectId",
                table: "tasks",
                newName: "ProjectID");

            migrationBuilder.RenameColumn(
                name: "Priority",
                table: "tasks",
                newName: "priority");

            migrationBuilder.RenameColumn(
                name: "Title",
                table: "tasks",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "tasks",
                newName: "T_id");

            migrationBuilder.AlterColumn<string>(
                name: "Role",
                table: "teamMembers",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50);

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "teamMembers",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.CreateTable(
                name: "ProjectTask",
                columns: table => new
                {
                    projectP_id = table.Column<int>(type: "int", nullable: false),
                    taskT_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectTask", x => new { x.projectP_id, x.taskT_id });
                    table.ForeignKey(
                        name: "FK_ProjectTask_projects_projectP_id",
                        column: x => x.projectP_id,
                        principalTable: "projects",
                        principalColumn: "P_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProjectTask_tasks_taskT_id",
                        column: x => x.taskT_id,
                        principalTable: "tasks",
                        principalColumn: "T_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TaskTeamMember",
                columns: table => new
                {
                    taskT_id = table.Column<int>(type: "int", nullable: false),
                    teamMemberTM_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TaskTeamMember", x => new { x.taskT_id, x.teamMemberTM_id });
                    table.ForeignKey(
                        name: "FK_TaskTeamMember_tasks_taskT_id",
                        column: x => x.taskT_id,
                        principalTable: "tasks",
                        principalColumn: "T_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TaskTeamMember_teamMembers_teamMemberTM_id",
                        column: x => x.teamMemberTM_id,
                        principalTable: "teamMembers",
                        principalColumn: "TM_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProjectTask_taskT_id",
                table: "ProjectTask",
                column: "taskT_id");

            migrationBuilder.CreateIndex(
                name: "IX_TaskTeamMember_teamMemberTM_id",
                table: "TaskTeamMember",
                column: "teamMemberTM_id");
        }
    }
}
