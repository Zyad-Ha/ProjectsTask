﻿using Microsoft.AspNetCore.Mvc;

namespace taskMVC.Controllers
{
    public class TeamMembersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
