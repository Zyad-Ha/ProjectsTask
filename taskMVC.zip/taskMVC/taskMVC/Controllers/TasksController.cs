﻿using Microsoft.AspNetCore.Mvc;

namespace taskMVC.Controllers
{
    public class TasksController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }



    }
}
