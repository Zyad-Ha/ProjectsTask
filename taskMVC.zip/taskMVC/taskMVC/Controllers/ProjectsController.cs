﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using taskMVC.Data;
using taskMVC.Models;
using taskMVC.Repos;
using taskMVC.ViewModels;
using Task = taskMVC.Models.Task;

namespace taskMVC.Controllers
{
    public class ProjectsController : Controller
    {
        private readonly Context _context;
        private readonly IProjectRepo _projectRepo;
        public ProjectsController(Context context, IProjectRepo projectRepo )
        {
            _context = context;
            _projectRepo = projectRepo;
        }
        public IActionResult Index()
        {
            var projects = _projectRepo.GetAll();
            return View(projects);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CreateProjectViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var project = new Project
            {
                Name = model.Name,
                Description = model.Description,
                StartDate = model.StartDate,
                EndDate = model.EndDate,
            };
            _projectRepo.Create(project);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id) 
        {
            var project = _context.projects.Find(id);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(UpdateProjectViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var upProject = new Project
            {
                Name = model.Name,
                Description = model.Description,
                StartDate = model.StartDate,
                EndDate = model.EndDate,

            };
            _projectRepo.Update(upProject);
            return RedirectToAction("Index");   
        }

        public IActionResult Delete(int id)
        {
            _projectRepo.Delete(id);
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
           var project = _projectRepo.Details(id);
            
            if (project == null)
            {
                return NotFound();
            }
            var viewModel = new DetailsProjectViewModel
            {
                Project = project,
                Tasks = project.Tasks,
            };
            return View(viewModel);
        }

        [HttpGet]
        public IActionResult EditTasks(int id)
        {
            var task = _context.tasks.Find(id);
            if (task == null)
            {
                return NotFound();
            }
            return View(task);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditTasks(Task task)
        {
           _context.tasks.Update(task);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult MemberDetails(int id)
        {
            var member = _context.teamMembers.Include(x=>x.Tasks).FirstOrDefault(c=>c.TM_id == id); 

            if (member == null) 
            {
                return NotFound();
            }
            return View(member);
        }
    }
}
