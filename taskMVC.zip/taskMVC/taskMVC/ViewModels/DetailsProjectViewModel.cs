﻿using taskMVC.Models;
using Task = taskMVC.Models.Task;

namespace taskMVC.ViewModels
{
    public class DetailsProjectViewModel
    {
        public Project Project {  get; set; }
        public ICollection<Task> Tasks { get; set; }
    }
}
