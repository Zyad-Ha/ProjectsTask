﻿using System.ComponentModel.DataAnnotations;

namespace taskMVC.ViewModels
{
    public class UpdateProjectViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
